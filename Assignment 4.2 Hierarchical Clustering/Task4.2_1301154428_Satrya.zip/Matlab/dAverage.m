function distance = dAverage( X , Y)
    % this function is to calculate the average between to point
    distance = (X + Y) / 2;
end