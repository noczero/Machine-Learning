function distance = dCompleteLink( X , Y )
    % this function is to choose the max from 2 cluster
    distance = max( X, Y);
end