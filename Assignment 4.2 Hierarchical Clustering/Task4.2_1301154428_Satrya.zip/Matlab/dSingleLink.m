function  distance = dSingleLink(X , Y)
    % this function is to calculate minimum distance between two cluster
     distance = min(X,Y);
end